package com.nirasha.smsweb.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.nirasha.smsweb.model.Document;
import com.nirasha.smsweb.repository.DocumentRepository;

public class DocumentServiceImpl implements DocumentService{

	@Autowired
	DocumentRepository documentRepository;
	@Override
	public Document save(Document document) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Document> fetch() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Document fetch(Integer id) {
		Optional <Document> document = documentRepository.findById(id);
		if (document.isPresent())
			return document.get();
		else
			return null;
	}

}
