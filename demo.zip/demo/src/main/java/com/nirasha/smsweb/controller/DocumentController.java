package com.nirasha.smsweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nirasha.smsweb.model.Document;
import com.nirasha.smsweb.service.DocumentService;

@RestController
@RequestMapping(value ="/dmscloud")
public class DocumentController {

	@Autowired
	DocumentService documentService;
	
	
	@RequestMapping(value="/document", method = RequestMethod.POST)
	public Document save(@RequestBody Document document) {
		
		return documentService.save(document);
	}
	
	@RequestMapping(value="/student", method = RequestMethod.GET)
	public List<Document> fetch(){
		return  documentService.fetch();
	}
	
	@RequestMapping(value="/student/{id}", method = RequestMethod.GET)
	public ResponseEntity<Document> fetch(@PathVariable Integer id){
		if (id<=0) {
			return ResponseEntity.badRequest().build();
		}
		else {
			Document document =  documentService.fetch(id);
			if(document == null)
				return ResponseEntity.notFound().build();
			else 
				return ResponseEntity.ok(document);
		}
		
	}
	
/*	@RequestMapping(value="/student/{id}/course", method = RequestMethod.GET)
	public ResponseEntity<List<Course>> fetch(@PathVariable Integer id){
		if (id<=0) {
			return ResponseEntity.badRequest().build();
		}
		else {
			Student student =  studentService.fetch(id);
			if(student == null)
				return ResponseEntity.notFound().build();
			else 
				return ResponseEntity.ok(student.getCourses());
		}
		
	}*/
	
}
