package com.nirasha.smsweb.service;

import java.util.List;


import com.nirasha.smsweb.model.Document;

public interface DocumentService {
	Document save(Document document);
	
	List<Document> fetch();
	
	Document fetch(Integer id);
}
